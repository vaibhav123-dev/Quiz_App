import React from "react";
import { Quiz } from "./Quiz";

export const Quizes = () => {
  return (
    <div>
      <Quiz />
    </div>
  );
};
