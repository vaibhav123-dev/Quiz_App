var res = [];
function coin(sz, arr, index, newArray) {
  //console.log(sz,arr)
  if (newArray.length != 0) {
    var sum = 0;
    for (var i = 0; i < newArray.length; i++) {
      sum = sum + newArray[i];
    }
    res.push(sum);
  }
  if (index == sz) {
    return;
  }
  for (var i = index; i < arr.length; i++) {
    newArray.push(arr[i]);
    coin(sz, arr, i + 1, newArray);
    newArray.pop();
  }
}
function runProgram(input) {
  input = input.split("\n");
  var arr = input[1].trim().split(" ").map(Number);
  var index = 0;
  var sz = +input[0];
  var newArray = [];
  res.sort((a, b) => a - b);
  coin(sz, arr, index, newArray);

  var obje = {};
  for (var i = 0; i < res.length; i++) {
    if (obje[res[i]] === undefined) {
      obje[res[i]] = 1;
    }
  }
  var counts = 0;
  var bag = "";
  for (var j in obje) {
    //console.log(obje)
    counts++;
    bag = bag + j + " ";
  }
  console.log(counts);
  console.log(bag);
}

if (process.env.USERNAME === "") {
  runProgram(``);
} else {
  process.stdin.resume();
  process.stdin.setEncoding("ascii");
  let read = "";
  process.stdin.on("data", function (input) {
    read += input;
  });
  process.stdin.on("end", function () {
    read = read.replace(/\n$/, "");
    read = read.replace(/\n$/, "");
    runProgram(read);
  });
  process.on("SIGINT", function () {
    read = read.replace(/\n$/, "");
    runProgram(read);
    process.exit(0);
  });
}
